package com.inca.npx.ste;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;

import javax.swing.JFileChooser;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

import com.inca.np.gui.ste.CSteModel;
import com.inca.np.gui.ste.ZxstejavaDelegate;

public class Delegate_101070_ste extends ZxstejavaDelegate {
	/**
	 * CSteModel�մ����ɹ�
	 * 
	 * @param model
	 */
	public void on_init(CSteModel model) {

	}

	/**
	 * �մ���GUI�ؼ�
	 */
	public void on_initControl() {

	}

	/**
	 * ���Ҽ�
	 * 
	 * @param stemodel
	 * @param row
	 * @param col
	 */
	public void on_rclick(CSteModel stemodel, int row, int col) {

	}

	/**
	 * ˫��
	 * 
	 * @param row
	 * @param col
	 */
	public void on_doubleclick(int row, int col) {

	}

	/**
	 * ɾ����
	 * 
	 * @param steModel
	 * @param row
	 */
	public void on_del(CSteModel steModel, int row) {

	}

	/**
	 * ɾ��ǰ
	 * 
	 * @param steModel
	 * @param row
	 * @return
	 */
	public int on_beforedel(CSteModel steModel, int row) {

		return 0;
	}

	/**
	 * �޸ĺ�
	 * 
	 * @param steModel
	 * @param row
	 */
	public void on_modify(CSteModel steModel, int row) {

	}

	/**
	 * �޸�ǰ
	 * 
	 * @param steModel
	 * @param row
	 * @return
	 */
	public int on_beforemodify(CSteModel steModel, int row) {
		return 0;
	}

	/**
	 * ��ѯ����
	 * 
	 * @param steModel
	 */
	public void on_retrieved(CSteModel steModel) {

	}

	/**
	 * ֵ�仯
	 * 
	 * @param steModel
	 * @param row
	 * @param colname
	 * @param value
	 */
	public void on_itemvaluechange(CSteModel steModel, int row, String colname,
			String value) {

	}

	/**
	 * ���ĵ�ǰǰ�仯��
	 * 
	 * @param steModel
	 * @param newrow
	 */
	public void on_tablerowchanged(CSteModel steModel, int newrow) {

	}

	/**
	 * �м��
	 * 
	 * @param steModel
	 * @param row
	 * @return
	 */
	public int on_checkrow(CSteModel steModel, int row) {

		return 0;
	}

	/**
	 * ���ڹر�ǰ
	 * 
	 * @param steModel
	 * @return
	 */
	public int on_beforeclose(CSteModel steModel) {

		return 0;
	}

	/**
	 * ����ǰ
	 * 
	 * @param steModel
	 * @return
	 */
	public int on_beforesave(CSteModel steModel) {

		return 0;
	}

	/**
	 * ��ѯǰ
	 * 
	 * @param steModel
	 * @return
	 */
	public int on_beforequery(CSteModel steModel) {

		return 0;
	}

	/**
	 * ������
	 * 
	 * @param steModel
	 * @param row
	 * @return
	 */
	public int on_new(CSteModel steModel, int row) {

		return 0;
	}

	/**
	 * ����ǰ
	 * 
	 * @param steModel
	 * @return
	 */
	public int on_beforeNew(CSteModel steModel) {

		return 0;
	}

	/**
	 * ��CSteModelѡ��hov�ɹ�����
	 * 
	 * @param steModel
	 * @param row
	 * @param colname
	 * @return
	 */
	public int on_hov(CSteModel steModel, int row, String colname) {
		return 0;
	}

	/**
	 * ���ظ��Ӳ�ѯ����
	 * 
	 * @return ���ظ��Ӳ�ѯ����
	 */
	public String getOtherWheres() {
		return "";
	}

	/**
	 * ��������
	 * 
	 * @param steModel
	 * @param command
	 * @return -1 ��ʾû�д������������С� ����0��ʾ��������ˡ�
	 */
	public int on_actionPerformed(CSteModel steModel, String command) {

		if ("dr".equals(command)) {
			HashMap<Integer, String> map = new HashMap<Integer, String>();
			HSSFRow hssfRow;
			int i = 0;// ��������
			JFileChooser c = new JFileChooser("asdfasdf");
			String d = "c:\\";
			c.setCurrentDirectory(new File(d));
			// c.setFileFilter(new ExcelFilter());
			c.setVisible(true);
			int rs = c.showOpenDialog(steModel.getParentFrame());
			if (rs == 0) {
				File file = c.getSelectedFile();

				String path = file.getAbsolutePath();

				InputStream is;
				HSSFWorkbook hssfWorkbook;
				try {
					is = new FileInputStream(path);
					hssfWorkbook = new HSSFWorkbook(is);

					// Read the Sheet
					for (int numSheet = 0; numSheet < hssfWorkbook
							.getNumberOfSheets(); numSheet++) {
						HSSFSheet hssfSheet = hssfWorkbook.getSheetAt(numSheet);
						if (hssfSheet == null) {
							continue;
						}
						// steModel.getParentFrame().infoMessage("��ʾ","������"+hssfSheet
						// .getLastRowNum());
						// Read the Row
						for (int rowNum = 0; rowNum <= hssfSheet
								.getLastRowNum(); rowNum++) {

							hssfRow = hssfSheet.getRow(rowNum);
							 if (hssfRow != null) {
							if (rowNum > 0) {
								i = steModel.getRowCount();
								steModel.getDBtableModel().appendRow();
								// steModel.getParentFrame().infoMessage("��ʾ","������"+hssfRow
								// .getPhysicalNumberOfCells());
							}
							// steModel.getParentFrame().infoMessage("��ʾ",i+"");
							for (int cellnum = 0; cellnum < hssfRow
									.getPhysicalNumberOfCells(); cellnum++) {

								if (rowNum == 0) {
									map.put(cellnum,
											getValue(hssfRow.getCell(cellnum)));

								} else {
									// steModel.getParentFrame()
									// .infoMessage(
									// "��ʾ",
									// map.get(cellnum)
									// + " "
									// + getValue(hssfRow
									// .getCell(cellnum)));
//									steModel.setItemValue(i, map.get(cellnum),
//											getValue(hssfRow.getCell(cellnum)));
									steModel.setItemValue(i, map.get(cellnum),
											getDate(hssfRow.getCell(cellnum)));

								}

								/*
								 * steModel.getParentFrame().infoMessage( "��ʾ",
								 * cellnum + "||" + getValue(hssfRow
								 * .getCell(cellnum)));
								 */
							}
							if (rowNum > 0) {
								steModel.tableChanged();
								steModel.setRow(i);
							}
							 }
						}
					}

				} catch (FileNotFoundException e) {

					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();
				}

				return 0;
			}

		}
		return -1;
	}

	private String getValue(HSSFCell hssfCell) {
		if (hssfCell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
			return String.valueOf(hssfCell.getBooleanCellValue());
		} else if (hssfCell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
			return String.valueOf(hssfCell.getNumericCellValue());
		} else {
			return String.valueOf(hssfCell.getStringCellValue());
		}
		
	}
	
	private String getDate(HSSFCell hssfCell){
        DecimalFormat df = new DecimalFormat("#");
        if(hssfCell == null){
            return "";
        }
        switch (hssfCell.getCellType()){
        case HSSFCell.CELL_TYPE_NUMERIC:
            if(HSSFDateUtil.isCellDateFormatted(hssfCell)){
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

                return sdf.format(HSSFDateUtil.getJavaDate(hssfCell.getNumericCellValue()));
            }

                return df.format(hssfCell.getNumericCellValue());
        case HSSFCell.CELL_TYPE_STRING:
            return hssfCell.getStringCellValue();
        case HSSFCell.CELL_TYPE_FORMULA:
            return hssfCell.getCellFormula();
        case HSSFCell.CELL_TYPE_BLANK:
            return "";

        }
    return "";


    }
}
